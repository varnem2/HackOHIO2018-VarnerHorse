
const Request = require('tedious').Request;
const Connection = require('tedious').Connection;
const config = {
    userName: 'varner@varnerhorse',
    password: 'HackingHorse1',
    server: 'varnerhorse.database.windows.net',
    options: {
        database: 'Inventory',
        encrypt: true
    }
};


module.exports = function(app, db){

};

module.exports = function(app,db){
    app.post('/notes', (req,res) =>{
        var myJSON = [];
        const connection = new Connection(config);
        connection.on('connect', err => {
            err ? console.log(err) : executeStatement();
        });
        //You'll create your note here.
        const query = req.body.title;
        const executeStatement = () => {
            const request = new Request(query, (err, rowCount) =>{
                if(err){console.log(err)};
                //err ? console.log(err) : console.log(rowCount);
                connection.close();
                console.log("Beore sending: " + myJSON);
                res.send(myJSON);
            });
            request.on('row', columns => {
                //columns.forEach(column => console.log(column.value));
                columns.forEach(column => myJSON.push(column.value));  
                //console.log("During Row: " + myJSON);              
            });
            
            connection.execSql(request);
            

        };
        
        
        console.log("Request Successful");
        
    });
};


function convertToJSON(array) {
    var objArray = [];
    for (var i = 1; i < array.length; i++) {
      objArray[i - 1] = {};
      for (var k = 0; k < array[0].length && k < array[i].length; k++) {
        var key = array[0][k];
        objArray[i - 1][key] = array[i][k]
      }
    }
  
    return objArray;
  }
#Requirements
Make sure that you have Docker installed.. Run to make sure that you get the docker container working.. Connects to Matt's Azure DB.

"$ docker build -t <your username>/node-web-app ."
